public class Main {

  public static void main(String[] args) {
    System.out.println("PRUEBA DE EXPLORADORES MARCIANOS (ROVERS)\n");

    // 1. Instanciación de Rovers
    Rover curiosity = new Rover("Curiosity");
    Rover perseverance = new Rover("Perseverance", 50.0);

    System.out.println("Rovers creados exitosamente.\n");

    // 2. Simulación de mandatos 
    curiosity.moverArriba();
    curiosity.moverArriba();
    curiosity.moverDerecha();
    curiosity.moverIzquierda();
    curiosity.moverAbajo();

    // Consultas individuales
    System.out.println("\nConsulta individual - " + curiosity.consultarPosicionActual());
    System.out.println("Consulta individual - Potencia disponible: " 
        + String.format("%.2f", curiosity.getPotenciaDisponible()) + " u");

    // Recarga de potencia
    System.out.println("\nEfectuando recarga de potencia...");
    curiosity.recargarUnidadesPotencia(20.0);

    // Intentar mas movimientos
    curiosity.moverArriba();
    curiosity.moverDerecha();

    // 3. Imprimir el estado completo del Rover 
    System.out.println("\n" + curiosity.toString());

    // 4. Prueba rápida 
    System.out.println("\n--- Ejecutando ordenes para Perseverance ---");
    perseverance.moverIzquierda();
    perseverance.moverAbajo();
    System.out.println("\n" + perseverance.toString());
  }
}