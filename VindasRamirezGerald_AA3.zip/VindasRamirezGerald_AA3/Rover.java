import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

public class Rover {

  private String nombrePropio;
  private double potenciaInicial;
  private double potenciaDisponible;
  private int posicionInicialX;
  private int posicionInicialY;
  private int posicionActualX;
  private int posicionActualY;
  private int cantidadRecargasRealizadas;
  private int contadorDeteccionesFuga;
  private ArrayList<ArrayList<String>> mandatosExitosos;
  private ArrayList<ArrayList<String>> mandatosFallidos;
  private double costoMovimiento;
  private double costoDeteccion;
  private int recargasMaximas;
  private String codigoRover;

  public Rover(String nombrePropio) {
    this(nombrePropio, 100.0);
  }

  public Rover(String nombrePropioP, double potencia) {
    this.nombrePropio = nombrePropioP;
    this.potenciaInicial = potencia;
    this.potenciaDisponible = potencia;
    this.posicionInicialX = 0;
    this.posicionInicialY = 0;
    this.posicionActualX = this.posicionInicialX;
    this.posicionActualY = this.posicionInicialY;
    this.cantidadRecargasRealizadas = 0;
    this.contadorDeteccionesFuga = 0;
    this.mandatosExitosos = new ArrayList<>();
    this.mandatosFallidos = new ArrayList<>();
    this.costoMovimiento = 0.50;
    this.costoDeteccion = 0.25;
    this.recargasMaximas = 5;
    this.codigoRover = "RVR-" + System.currentTimeMillis() % 100000;
  }

  public void moverIzquierda() {
    if (validarPotenciaActual()) {
      if (!detectarFuga()) {
        this.posicionActualX -= 1;
        this.potenciaDisponible -= this.costoMovimiento;
        registrarMandato("Desplazamiento Izquierda", "Posible");
      } else {
        registrarMandato("Desplazamiento Izquierda", "No posible: fuga detectada");
      }
    } else {
      registrarMandato("Desplazamiento Izquierda", "No posible: potencia insuficiente");
    }
  }

  public void moverDerecha() {
    if (validarPotenciaActual()) {
      if (!detectarFuga()) {
        this.posicionActualX += 1;
        this.potenciaDisponible -= this.costoMovimiento;
        registrarMandato("Desplazamiento Derecha", "Posible");
      } else {
        registrarMandato("Desplazamiento Derecha", "No posible: fuga detectada");
      }
    } else {
      registrarMandato("Desplazamiento Derecha", "No posible: potencia insuficiente");
    }
  }

  public void moverArriba() {
    if (validarPotenciaActual()) {
      if (!detectarFuga()) {
        this.posicionActualY += 1;
        this.potenciaDisponible -= this.costoMovimiento;
        registrarMandato("Desplazamiento Arriba", "Posible");
      } else {
        registrarMandato("Desplazamiento Arriba", "No posible: fuga detectada");
      }
    } else {
      registrarMandato("Desplazamiento Arriba", "No posible: potencia insuficiente");
    }
  }

  public void moverAbajo() {
    if (validarPotenciaActual()) {
      if (!detectarFuga()) {
        this.posicionActualY -= 1;
        this.potenciaDisponible -= this.costoMovimiento;
        registrarMandato("Desplazamiento Abajo", "Posible");
      } else {
        registrarMandato("Desplazamiento Abajo", "No posible: fuga detectada");
      }
    } else {
      registrarMandato("Desplazamiento Abajo", "No posible: potencia insuficiente");
    }
  }

  public String consultarPosicionActual() {
    return "Posición actual (x,y): " + this.posicionActualX + ", " + this.posicionActualY;
  }

  public double getPotenciaDisponible() {
    return this.potenciaDisponible;
  }

  public void recargarUnidadesPotencia(double potencia) {
    if (validarRecarga()) {
      this.potenciaDisponible += potencia;
      this.cantidadRecargasRealizadas++;
      registrarMandato("Recarga (" + potencia + ")", "Posible");
    } else {
      registrarMandato("Recarga (" + potencia + ")", "No posible: recargas agotadas");
    }
  }

  private boolean detectarFuga() {
    this.contadorDeteccionesFuga++;
    this.potenciaDisponible -= this.costoDeteccion;
    Random random = new Random();
    return random.nextDouble() >= 0.5;
  }

  private boolean validarRecarga() {
    return (this.cantidadRecargasRealizadas < this.recargasMaximas) ? true : false;
  }

  private boolean validarPotenciaActual() {
    double costoMinimo = this.costoMovimiento + this.costoDeteccion;
    return this.potenciaDisponible >= costoMinimo;
  }

  private String determinarFechaHoraActual() {
    Date fecha = new Date(System.currentTimeMillis());
    DateFormat formatoFecha = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
    return formatoFecha.format(fecha);
  }

  private void registrarMandato(String tipoMandato, String estatusMandato) {
    ArrayList<String> mandato = new ArrayList<>();
    mandato.add(tipoMandato);
    mandato.add(estatusMandato);
    mandato.add(determinarFechaHoraActual());

    if ("Posible".compareTo(estatusMandato) == 0) {
      this.mandatosExitosos.add(mandato);
    } else {
      this.mandatosFallidos.add(mandato);
    }
  }

  public String toString() {
    String msg = "";
    msg += "========== Ficha del Rover ==========\n";
    msg += "Código: " + this.codigoRover + "\n";
    msg += "Nombre: " + this.nombrePropio + "\n";
    msg += "Potencia (inicial/disponible): " + String.format("%.2f / %.2f", this.potenciaInicial, this.potenciaDisponible) + "\n";
    msg += "Posición (inicial → actual): (" + this.posicionInicialX + "," + this.posicionInicialY + ") → (" + this.posicionActualX + "," + this.posicionActualY + ")\n";
    msg += "Costos (mov/detección): " + String.format("%.2f / %.2f", this.costoMovimiento, this.costoDeteccion) + "\n";
    msg += "Recargas (realizadas/máximas): " + this.cantidadRecargasRealizadas + "/" + this.recargasMaximas + "\n";
    msg += "Detecciones de fuga realizadas: " + this.contadorDeteccionesFuga + "\n";
    msg += "=====================================\n\n";

    msg += "---- Registro de Mandatos EXITOSOS ----\n";
    msg += String.format(" %-4s %-17s %-30s %-20s%n", "N°", "Fecha", "Mandato", "Estado");
    for (int i = 0; i < this.mandatosExitosos.size(); i++) {
      ArrayList<String> m = this.mandatosExitosos.get(i);
      String tipo = (m.size() > 0) ? m.get(0) : "";
      String estado = (m.size() > 1) ? m.get(1) : "";
      String fecha = (m.size() > 2) ? m.get(2) : "";
      msg += String.format(" %-4d %-17s %-30s %-20s%n", (i + 1), fecha, tipo, estado);
    }
    if (this.mandatosExitosos.isEmpty()) {
      msg += " (sin registros)\n";
    }

    msg += "\n";
    msg += "---- Registro de Mandatos FALLIDOS ----\n";
    msg += String.format(" %-4s %-17s %-30s %-20s%n", "N°", "Fecha", "Mandato", "Estado");
    for (int i = 0; i < this.mandatosFallidos.size(); i++) {
      ArrayList<String> m = this.mandatosFallidos.get(i);
      String tipo = (m.size() > 0) ? m.get(0) : "";
      String estado = (m.size() > 1) ? m.get(1) : "";
      String fecha = (m.size() > 2) ? m.get(2) : "";
      msg += String.format(" %-4d %-17s %-30s %-20s%n", (i + 1), fecha, tipo, estado);
    }
    if (this.mandatosFallidos.isEmpty()) {
      msg += " (sin registros)\n";
    }

    return msg;
  }
}